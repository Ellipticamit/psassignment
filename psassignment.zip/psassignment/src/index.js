import './scss/main.scss';
import './components/banner';
import './components/categories';


