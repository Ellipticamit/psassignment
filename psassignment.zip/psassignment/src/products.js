import './scss/main.scss';
import "./components/productdata.js";