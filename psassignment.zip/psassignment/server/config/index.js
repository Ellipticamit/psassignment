const baseConfig = {
    env: process.env.NODE_ENV || 'developmnet',
    port: process.env.PORT || 3003,
}
module.exports = baseConfig;